import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://lusd1.org/kodi/builds/build-addons/builds.xml'