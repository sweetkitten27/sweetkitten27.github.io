import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/scl/fi/wfizagdfaosouzjinvdg3/builds.xml?rlkey=f5hsfu62zzscd8jgxrfbivijj&st=p50g8bzx&dl=1'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/Buildtexts69/omegabuilds/main/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']