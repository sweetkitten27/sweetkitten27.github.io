import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://lusd1.org/kodi/builds/build-addons/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/Buildtexts69/omegabuilds/main/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']